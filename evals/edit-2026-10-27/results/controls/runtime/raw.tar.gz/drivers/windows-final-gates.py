import json
from pathlib import Path
import subprocess
root=Path.cwd();lead=root/'target/edit-evaluation/lead'
commands=[
 ('rust', ['cargo','test','--workspace','--locked','--no-fail-fast']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--','-D','warnings']),
 ('fmt',['cargo','fmt','--all','--','--check']),
 ('release',['cargo','build','--release','--locked']),
 ('plugin',['node','--test','tests/plugin/*.test.cjs']),
 ('hashes',['powershell','-NoProfile','-Command','Get-FileHash target/release/code-kb.exe -Algorithm SHA256; Get-ChildItem .tools -File | Get-FileHash -Algorithm SHA256']),
 ('state',['git','status','--short','--branch']),
 ('commit',['git','rev-parse','HEAD']),
]
report={'schema':1,'host_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commands':[]}
try:
 for label,argv in commands:
  log=lead/('windows-'+label+'-final.log')
  with log.open('w') as output:result=subprocess.run(['win-test','run',str(root),'--',*argv],stdout=output,stderr=subprocess.STDOUT)
  report['commands'].append({'scope':label,'argv':argv,'exit_status':result.returncode,'dispatch_log':str(log)})
  print(json.dumps(report['commands'][-1]),flush=True)
  if result.returncode:break
finally:
 down=subprocess.run(['win-test','down'],capture_output=True,text=True)
 report['shutdown']={'exit_status':down.returncode,'stdout':down.stdout,'stderr':down.stderr}
 (lead/'windows-final-gates.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'shutdown':report['shutdown']}),flush=True)
raise SystemExit(0 if len(report['commands'])==len(commands) and all(x['exit_status']==0 for x in report['commands']) and down.returncode==0 else 1)
