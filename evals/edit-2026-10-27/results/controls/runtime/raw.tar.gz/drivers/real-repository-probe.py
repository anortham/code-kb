from pathlib import Path
p=Path('.razorback/watcher-registration/probe.py')
s=p.read_text().replace("parser.add_argument('--create-fixture', action='store_true')", "parser.add_argument('--create-fixture', action='store_true')\n    parser.add_argument('--probe-file', default='src/lib.rs')\n    parser.add_argument('--probe-symbol', default='watch_probe')")
s=s.replace("'file_path': 'src/lib.rs'", "'file_path': args.probe_file").replace("if 'watch_probe' not in str(outline):", "if args.probe_symbol not in str(outline):")
s=s.replace("'excluded_leaf_directories': 1000", "'excluded_leaf_directories': None, 'probe_file': args.probe_file, 'probe_symbol': args.probe_symbol")
exec(compile(s,str(p),'exec'))
