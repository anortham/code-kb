#!/usr/bin/env python3
"""Verify code-kb scan and MCP controls against the six durable evaluation seeds."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path, PurePosixPath
from typing import Any


ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))

import edit_evaluation
import edit_sandbox
import edit_snapshot


CASE_IDS = ("sqlglot", "minijinja", "hcl", "date-fns", "commons-lang", "nodatime")
LOOKUPS = {
    "sqlglot": ("_build_date", "sqlglot/parsers/bigquery.py"),
    "minijinja": ("SyntaxElements", "minijinja-cli/src/config.rs"),
    "hcl": ("ImpliedBodySchema", "gohcl/schema.go"),
    "date-fns": ("addBusinessDays", "pkgs/core/src/addBusinessDays/index.ts"),
    "commons-lang": ("ObjectUtils", "src/main/java/org/apache/commons/lang3/ObjectUtils.java"),
    "nodatime": ("LocalDate", "src/NodaTime/LocalDate.cs"),
}
DEFAULT_BINDINGS = ROOT / "target/edit-evaluation/lead/runtime-bindings.json"
DEFAULT_RESULTS = ROOT / "target/edit-evaluation/lead/final-mcp-controls-final"
MCP_DRIVER = r'''
import json
import os
import select
import subprocess
import sys
import time
import traceback

binary, project, query, source_path = sys.argv[1:]
forbidden_schema_names = {"workspace", "workspace_id", "repo_path", "root_dir", "root"}
process = None
server_log = None
result = {"query": query, "path": source_path}
failure = None
try:
    server_log = open("/state/code-kb-mcp.stderr.log", "xb")
    started = time.monotonic()
    process = subprocess.Popen(
        [binary, "--root", project, "serve"],
        cwd=project,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=server_log,
        text=True,
        encoding="utf-8",
        bufsize=1,
    )
    spawned = time.monotonic()

    def request(method, params, request_id):
        payload = {"jsonrpc": "2.0", "id": request_id, "method": method}
        if params is not None:
            payload["params"] = params
        process.stdin.write(json.dumps(payload, separators=(",", ":")) + "\n")
        process.stdin.flush()
        ready, _, _ = select.select([process.stdout], [], [], 120)
        if not ready:
            raise TimeoutError("timed out waiting for MCP " + method)
        line = process.stdout.readline()
        if not line:
            raise RuntimeError("MCP server closed stdout during " + method)
        response = json.loads(line)
        if response.get("id") != request_id:
            raise RuntimeError("MCP response id did not match " + method)
        if "error" in response:
            raise RuntimeError("MCP " + method + " failed: " + json.dumps(response["error"], sort_keys=True))
        if "result" not in response:
            raise RuntimeError("MCP " + method + " returned no result")
        return response["result"]

    initialize_started = time.monotonic()
    initialize = request(
        "initialize",
        {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "final-mcp-controls", "version": "1"},
        },
        1,
    )
    initialize_finished = time.monotonic()
    if initialize.get("protocolVersion") != "2024-11-05":
        raise RuntimeError("MCP initialize returned an unexpected protocol version")
    process.stdin.write(json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n")
    process.stdin.flush()

    tools_started = time.monotonic()
    tool_list = request("tools/list", {}, 2)
    tools_finished = time.monotonic()
    tools = tool_list.get("tools")
    expected_names = [
        "file_skeleton",
        "lookup_symbol",
        "get_symbol_body",
        "get_symbol_context",
        "find_references",
        "blast_radius",
        "check_edit",
    ]
    actual_names = [tool.get("name") for tool in tools] if isinstance(tools, list) else []
    if len(actual_names) != len(expected_names) or set(actual_names) != set(expected_names):
        raise RuntimeError("tools/list returned unexpected tool names: " + json.dumps(actual_names))
    schema_report = {}
    for tool in tools:
        schema = tool.get("inputSchema")
        if not isinstance(schema, dict):
            raise RuntimeError("tool has no inputSchema: " + str(tool.get("name")))
        properties = schema.get("properties")
        required = schema.get("required")
        if not isinstance(properties, dict) or "project_root" not in properties:
            raise RuntimeError("tool schema lacks project_root: " + str(tool.get("name")))
        if not isinstance(required, list) or "project_root" not in required:
            raise RuntimeError("tool schema does not require project_root: " + str(tool.get("name")))
        forbidden = sorted(forbidden_schema_names.intersection(properties))
        if forbidden:
            raise RuntimeError("tool schema exposes forbidden root aliases: " + str(tool.get("name")))
        schema_report[tool["name"]] = {
            "project_root_property": True,
            "project_root_required": True,
            "forbidden_root_aliases": forbidden,
        }

    lookup_started = time.monotonic()
    lookup = request(
        "tools/call",
        {
            "name": "lookup_symbol",
            "arguments": {"query": query, "path": source_path, "project_root": project},
        },
        3,
    )
    lookup_finished = time.monotonic()
    if lookup.get("isError"):
        raise RuntimeError("lookup_symbol returned an MCP tool error")
    content = lookup.get("content")
    if not isinstance(content, list):
        raise RuntimeError("lookup_symbol returned no content array")
    text = "\n".join(item.get("text", "") for item in content if isinstance(item, dict) and item.get("type") == "text")
    if query not in text or source_path not in text:
        raise RuntimeError("lookup_symbol did not return the requested source symbol and path")

    result.update(
        {
            "status": "passed",
            "protocol_version": initialize["protocolVersion"],
            "server_info": initialize.get("serverInfo"),
            "tool_names": actual_names,
            "tools": schema_report,
            "lookup_symbol": {"isError": False, "text": text},
            "timing_seconds": {
                "process_spawn": round(spawned - started, 6),
                "mcp_startup_and_initialize": round(initialize_finished - started, 6),
                "initialize_request": round(initialize_finished - initialize_started, 6),
                "tools_list": round(tools_finished - tools_started, 6),
                "lookup": round(lookup_finished - lookup_started, 6),
                "mcp_total": round(lookup_finished - started, 6),
            },
        }
    )
except Exception as error:
    failure = error
finally:
    if process is not None:
        try:
            if process.stdin is not None and not process.stdin.closed:
                process.stdin.close()
            process.wait(timeout=5)
        except Exception:
            if process.poll() is None:
                process.kill()
                process.wait()
        result["mcp_server_exit_status"] = process.returncode
    if server_log is not None:
        server_log.close()

if failure is not None:
    result.update({"status": "failed", "error": str(failure)})
    traceback.print_exception(failure, file=sys.stderr)
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(1)
if result.get("mcp_server_exit_status") != 0:
    result.update({"status": "failed", "error": "MCP server did not exit cleanly"})
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(1)
print(json.dumps(result, sort_keys=True))
'''


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError(f"expected a bounded regular JSON file: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected an object in {path}")
    return value


def write_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def require_executable(path: Path, label: str) -> Path:
    if path.is_symlink() or not path.is_file() or not os.access(path, os.X_OK):
        raise ValueError(f"{label} must be an executable regular file: {path}")
    return path.resolve(strict=True)


def validate_bindings(path: Path) -> tuple[dict[str, Any], dict[str, Path]]:
    bindings = read_json(path)
    if bindings.get("schema") != 1:
        raise ValueError("runtime bindings schema must be 1")
    cases = bindings.get("cases")
    seeds = bindings.get("seeds")
    if not isinstance(cases, dict) or not isinstance(seeds, dict) or set(cases) != set(CASE_IDS) or set(seeds) != set(CASE_IDS):
        raise ValueError("runtime bindings must contain the six named cases and seeds")
    control_input = Path(bindings["control_root"])
    intelligence_input = Path(bindings["intelligence_tools"])
    if control_input.is_symlink() or intelligence_input.is_symlink():
        raise ValueError("control_root and intelligence_tools cannot be symlinks")
    control_root = control_input.resolve(strict=True)
    intelligence = intelligence_input.resolve(strict=True)
    if not control_root.is_dir() or not intelligence.is_dir():
        raise ValueError("control_root and intelligence_tools must be directories")
    expected_files = {"code-kb", "julie-extract"}
    actual_files = {entry.name for entry in intelligence.iterdir()}
    if actual_files != expected_files:
        raise ValueError(f"intelligence_tools must contain exactly {sorted(expected_files)}")
    tools = {
        "code-kb": require_executable(intelligence / "code-kb", "code-kb"),
        "julie-extract": require_executable(intelligence / "julie-extract", "julie-extract"),
    }
    return bindings, {"directory": intelligence, **tools}


def assert_hidden_paths_absent(project: Path, case: dict[str, Any]) -> list[dict[str, Any]]:
    evidence = []
    for hidden in case["hidden_files"]:
        relative = hidden["path"]
        current = project
        for part in PurePosixPath(relative).parts:
            if current.is_symlink():
                raise ValueError(f"hidden path traverses a symlink in project: {relative}")
            current = current / part
        if current.exists() or current.is_symlink():
            raise ValueError(f"hidden destination unexpectedly exists: {relative}")
        evidence.append({"destination": relative, "absent": True})
    return evidence


def require_regular_project_file(project: Path, relative: str) -> Path:
    current = project
    for part in PurePosixPath(relative).parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"source lookup path traverses a symlink: {relative}")
    if not current.is_file():
        raise ValueError(f"source lookup path is not a regular file in the seed: {relative}")
    return current


def result_file_evidence(run_report: dict[str, Any]) -> dict[str, Any]:
    evidence = {}
    for key in ("stdout_log", "stderr_log"):
        value = run_report.get(key)
        if isinstance(value, str):
            path = Path(value)
            evidence[key] = {
                "path": str(path),
                "sha256": sha256_file(path) if path.is_file() else None,
                "exists": path.is_file(),
            }
    return evidence


def parse_driver_result(run_report: dict[str, Any]) -> dict[str, Any]:
    stdout_log = run_report.get("stdout_log")
    if not isinstance(stdout_log, str) or not Path(stdout_log).is_file():
        raise ValueError("sandbox did not retain MCP driver stdout")
    stdout_path = Path(stdout_log)
    if stdout_path.stat().st_size > 1024 * 1024:
        raise ValueError("MCP driver stdout exceeds the diagnostic limit")
    lines = [line for line in stdout_path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip()]
    if not lines:
        raise ValueError("MCP driver returned no JSON result")
    result = json.loads(lines[-1])
    if not isinstance(result, dict):
        raise ValueError("MCP driver returned a non-object result")
    return result


def verify_source_snapshot(seed: Path, project: Path, case: dict[str, Any]) -> str:
    excluded = [*case["generated_roots"], ".code-kb"]
    seed_digest = edit_snapshot.snapshot_tree(seed, excluded=excluded)["digest"]
    project_digest = edit_snapshot.snapshot_tree(project, excluded=excluded)["digest"]
    if project_digest != seed_digest:
        raise ValueError("reused scan project source differs from its pinned seed")
    return project_digest


def load_prior_scans(
    path: Path,
    bindings: dict[str, Any],
    tools_sha256: str,
) -> tuple[Path, dict[str, dict[str, Any]], str, str]:
    prior_root = path.resolve(strict=True)
    if not prior_root.is_dir():
        raise ValueError("scan reuse path must be a directory")
    prior_report = read_json(prior_root / "report.json")
    if prior_report.get("intelligence_tools_tree_sha256") != tools_sha256:
        raise ValueError("scan reuse report was created with different intelligence tools")
    prior_cases = {item.get("repo_id"): item for item in prior_report.get("cases", []) if isinstance(item, dict)}
    if set(prior_cases) != set(CASE_IDS):
        raise ValueError("scan reuse report does not contain all six cases")
    for repo_id, item in prior_cases.items():
        scan = item.get("scan")
        sandbox = scan.get("sandbox") if isinstance(scan, dict) else None
        project = prior_root / repo_id / "project"
        if (
            not isinstance(sandbox, dict)
            or sandbox.get("timed_out")
            or sandbox.get("exit_status") != 0
            or scan.get("mode") != "grade"
            or scan.get("network") is not False
            or scan.get("dependencies") != {}
            or scan.get("tools") != ["intelligence"]
            or item.get("source_pin") != bindings["seeds"][repo_id]["source_pin"]
            or item.get("seed_digest") != bindings["seeds"][repo_id]["seed_digest"]
            or item.get("clone_digest_before_scan") != bindings["seeds"][repo_id]["seed_digest"]
            or item.get("seed_unchanged") is not True
            or project.is_symlink()
            or not project.is_dir()
            or Path(item.get("copied_project", "")).resolve(strict=True) != project.resolve(strict=True)
        ):
            raise ValueError(f"scan reuse case is not a verified successful seed scan: {repo_id}")
        for log in scan.get("evidence", {}).values():
            log_path = Path(log.get("path", "")).resolve(strict=True)
            if prior_root not in log_path.parents or log_path.is_symlink() or not log_path.is_file() or sha256_file(log_path) != log.get("sha256"):
                raise ValueError(f"scan reuse log is missing or stale: {repo_id}")
    return (
        prior_root,
        prior_cases,
        prior_report.get("bindings_sha256", ""),
        prior_report.get("intelligence_tools", ""),
    )


def run_case(
    repo_id: str,
    bindings: dict[str, Any],
    tools: dict[str, Path],
    results_root: Path,
    prior_scans: tuple[Path, dict[str, dict[str, Any]], str, str] | None = None,
) -> dict[str, Any]:
    case_dir = ROOT / "evals/edit-2026-10-27/cases" / repo_id
    case_file = case_dir / "case.json"
    case = edit_evaluation.validate_case(case_dir, verify_assets=False)
    if case["repo_id"] != repo_id:
        raise ValueError(f"case repo_id mismatch for {repo_id}")
    seed_binding = bindings["seeds"][repo_id]
    seed_input = Path(seed_binding["seed_project"])
    if seed_input.is_symlink():
        raise ValueError(f"seed project cannot be a symlink: {seed_input}")
    seed = seed_input.resolve(strict=True)
    if not seed.is_dir():
        raise ValueError(f"seed project is not a regular directory: {seed}")
    if seed_binding["source_pin"] != case["source_pin"]:
        raise ValueError(f"case and durable seed source pins differ for {repo_id}")
    seed_digest = edit_evaluation.hash_tree(seed)
    if seed_digest != seed_binding["seed_digest"]:
        raise ValueError(f"durable seed digest changed for {repo_id}")

    case_results = results_root / repo_id
    case_results.mkdir(mode=0o700)
    prior_case = prior_scans[1][repo_id] if prior_scans else None
    if prior_scans:
        project = prior_scans[0] / repo_id / "project"
        if sha256_file(case_file) != prior_case.get("case_json_sha256"):
            raise ValueError(f"case contract changed since the preserved scan: {repo_id}")
        verify_source_snapshot(seed, project, case)
        scan_record = prior_case["scan"]
        scan_run = scan_record["sandbox"]
        scan_wall_seconds = scan_record["wall_seconds"]
        scan_evidence = scan_record["evidence"]
        clone_digest = prior_case["clone_digest_before_scan"]
    else:
        project = case_results / "project"
        shutil.copytree(seed, project, symlinks=True)
        os.chmod(project, 0o700)
        clone_digest = edit_evaluation.hash_tree(project)
        if clone_digest != seed_digest:
            raise ValueError(f"copied seed does not match its durable tree digest for {repo_id}")
    hidden_absence = assert_hidden_paths_absent(seed, case)
    hidden_absence.extend(
        {"destination": item["destination"], "absent_in_copy": True}
        for item in assert_hidden_paths_absent(project, case)
    )
    query, source_path = LOOKUPS[repo_id]
    require_regular_project_file(project, source_path)

    environment_assignment = "JULIE_EXTRACT_BIN=/tools/intelligence/julie-extract"
    scan_state = case_results / "state"
    if not prior_scans:
        scan_output = case_results / "scan-output"
        scan_started = time.monotonic()
        scan_run = edit_sandbox.run(
            project,
            scan_state,
            scan_output,
            900,
            "grade",
            [
                "/usr/bin/env",
                "-C",
                edit_sandbox.CONTAINER_PROJECT,
                environment_assignment,
                "/tools/intelligence/code-kb",
                "--root",
                edit_sandbox.CONTAINER_PROJECT,
                "scan",
            ],
            dependencies={},
            tools={"intelligence": tools["directory"]},
            network=False,
        )
        scan_wall_seconds = round(time.monotonic() - scan_started, 6)
        scan_evidence = result_file_evidence(scan_run)
    if scan_run.get("timed_out") or scan_run.get("exit_status") != 0:
        seed_after = edit_evaluation.hash_tree(seed)
        return {
            "repo_id": repo_id,
            "status": "failed",
            "stage": "scan",
            "scan": {"run": scan_run, "wall_seconds": scan_wall_seconds, "evidence": scan_evidence},
            "seed_digest": seed_digest,
            "seed_digest_after_runs": seed_after,
            "seed_unchanged": seed_after == seed_digest,
            "copied_project": str(project),
            "clone_digest_before_scan": clone_digest,
            "hidden_destinations": hidden_absence,
        }

    mcp_output = case_results / "mcp-output"
    mcp_started = time.monotonic()
    mcp_run = edit_sandbox.run(
        project,
        scan_state,
        mcp_output,
        240,
        "grade",
        [
            "/usr/bin/env",
            "-C",
            edit_sandbox.CONTAINER_PROJECT,
            environment_assignment,
            "/usr/bin/python3",
            "-c",
            MCP_DRIVER,
            "/tools/intelligence/code-kb",
            edit_sandbox.CONTAINER_PROJECT,
            query,
            source_path,
        ],
        dependencies={},
        tools={"intelligence": tools["directory"]},
        network=False,
    )
    mcp_wall_seconds = round(time.monotonic() - mcp_started, 6)
    mcp_evidence = result_file_evidence(mcp_run)
    mcp_state_log = scan_state / "code-kb-mcp.stderr.log"
    try:
        mcp_payload = parse_driver_result(mcp_run)
    except Exception as error:
        mcp_payload = {"status": "failed", "error": f"{type(error).__name__}: {error}"}
    seed_after = edit_evaluation.hash_tree(seed)
    status = "passed" if (
        not mcp_run.get("timed_out")
        and mcp_run.get("exit_status") == 0
        and mcp_payload.get("status") == "passed"
        and seed_after == seed_digest
    ) else "failed"
    return {
        "repo_id": repo_id,
        "status": status,
        "source_pin": case["source_pin"],
        "case_json_sha256": sha256_file(case_file),
        "seed_project": str(seed),
        "seed_digest": seed_digest,
        "seed_digest_after_runs": seed_after,
        "seed_unchanged": seed_after == seed_digest,
        "copied_project": str(project),
        "clone_digest_before_scan": clone_digest,
        "clone_digest_after_runs": edit_evaluation.hash_tree(project),
        "hidden_destinations": hidden_absence,
        "mounted_case_oracle_paths": [],
        "scan": {
            "mode": "grade",
            "network": False,
            "dependencies": {},
            "tools": ["intelligence"],
            "wall_seconds": scan_wall_seconds,
            "sandbox": scan_run,
            "evidence": scan_evidence,
            "tool_source": prior_scans[3] if prior_scans else str(tools["directory"]),
            "reused_from": (
                {"case_result": str(prior_scans[0] / repo_id), "bindings_sha256": prior_scans[2]}
                if prior_scans
                else None
            ),
        },
        "mcp": {
            "mode": "grade",
            "network": False,
            "dependencies": {},
            "tools": ["intelligence"],
            "tool_source": str(tools["directory"]),
            "wall_seconds": mcp_wall_seconds,
            "sandbox": mcp_run,
            "driver": mcp_payload,
            "evidence": mcp_evidence,
            "server_stderr": {
                "path": str(mcp_state_log),
                "exists": mcp_state_log.is_file(),
                "sha256": sha256_file(mcp_state_log) if mcp_state_log.is_file() else None,
            },
        },
    }


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--bindings", type=Path, default=DEFAULT_BINDINGS)
    value.add_argument("--results", type=Path, default=DEFAULT_RESULTS)
    value.add_argument("--reuse-scans-from", type=Path)
    return value


def main() -> int:
    args = parser().parse_args()
    bindings_path = args.bindings.resolve(strict=True)
    results_root = args.results.expanduser().absolute()
    if results_root.exists() or results_root.is_symlink():
        raise SystemExit(f"refusing to overwrite existing results directory: {results_root}")
    bindings, tools = validate_bindings(bindings_path)
    bindings_sha256 = sha256_file(bindings_path)
    tools_tree_sha256 = edit_evaluation.hash_tree(tools["directory"])
    prior_scans = load_prior_scans(args.reuse_scans_from, bindings, tools_tree_sha256) if args.reuse_scans_from else None
    results_root.mkdir(parents=True, mode=0o700)
    os.chmod(results_root, 0o700)
    executable_hashes = {name: sha256_file(path) for name, path in tools.items() if name != "directory"}
    report: dict[str, Any] = {
        "schema": 1,
        "status": "running",
        "started_unix_seconds": time.time(),
        "worktree": str(ROOT),
        "bindings": str(bindings_path),
        "bindings_sha256": bindings_sha256,
        "intelligence_tools": str(tools["directory"]),
        "intelligence_tools_tree_sha256": tools_tree_sha256,
        "intelligence_executable_sha256": executable_hashes,
        "diagnostic_script_sha256": sha256_file(Path(__file__).resolve()),
        "superseded_attempts": [
            {
                "results": str(ROOT / "target/edit-evaluation/lead/final-mcp-controls-attempt-1"),
                "classification": "harness_failure_not_product_or_scored_outcome",
                "cause": "The diagnostic asserted the wrong final MCP tool name.",
            },
            {
                "results": str(ROOT / "target/edit-evaluation/lead/final-mcp-controls"),
                "classification": "harness_failure_not_product_or_scored_outcome",
                "cause": "The diagnostic expected edit_check; the MCP tool is named check_edit.",
            },
        ],
        "isolation": {
            "mode": "grade",
            "network": False,
            "dependencies_mounted": [],
            "tools_mounted": ["intelligence"],
            "credentials_mounted": False,
            "private_profile_mounted": False,
            "auth_file_mounted": False,
            "case_metadata_mounted": False,
            "hidden_fixture_mounts": [],
            "oracle_mounts": [],
        },
        "cases": [],
    }
    write_json(results_root / "report.json", report)
    for repo_id in CASE_IDS:
        try:
            item = run_case(repo_id, bindings, tools, results_root, prior_scans)
        except Exception as error:
            item = {"repo_id": repo_id, "status": "failed", "error": f"{type(error).__name__}: {error}"}
        report["cases"].append(item)
        write_json(results_root / "report.json", report)
    report["status"] = "passed" if all(item.get("status") == "passed" for item in report["cases"]) else "failed"
    report["finished_unix_seconds"] = time.time()
    write_json(results_root / "report.json", report)
    print(json.dumps({"results": str(results_root / "report.json"), "status": report["status"]}, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
