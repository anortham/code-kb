import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import edit_evaluation as e
root=Path.cwd(); study=root/'evals/edit-2026-10-27'; lead=root/'target/edit-evaluation/lead'
frozen=json.loads((study/'frozen-inputs.json').read_text())
bindings=json.loads((lead/'runtime-bindings.json').read_text())
paths={
 'codex':Path('/home/murphy/.local/share/mise/installs/node/24.18.1/lib/node_modules/@openai/codex/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin/codex'),
 'protocol':study/'protocol.md','corpus':study/'corpus.json',
 'snapshot':root/'scripts/edit_snapshot.py','sandbox':root/'scripts/edit_sandbox.py',
 'runner':root/'scripts/edit_evaluation.py',
 'extractor':Path(bindings['intelligence_tools'])/'julie-extract',
 'binary':Path(bindings['intelligence_tools'])/'code-kb',
 'guidance':study/'guidance','profiles':study/'profiles',
 'frozen_inputs':study/'frozen-inputs.json',
 'readiness_archive':study/'results/readiness/raw.tar.gz',
}
paths.update({key:Path(value['host_path']) for key,value in frozen['inputs'].items()})
def digest(p):
 return e.hash_tree(p) if p.is_dir() else hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
controls={'model':'gpt-6.1-sol','effort':'high','timeout_seconds':900}
for key,path in paths.items():
 controls[key+'_sha256']=digest(path)
 if key in frozen['inputs']:
  assert controls[key+'_sha256']==frozen['inputs'][key]['sha256'], key
cases=[]
for item in json.loads((study/'corpus.json').read_text())['repositories']:
 key=item['id'];case=study/'cases'/key;ready=study/'results/readiness'/key/'readiness.json'
 cases.append({'id':key,'repo_id':key,'pin':item['commit'],'case_path':str(case.relative_to(study)),'readiness_path':str(ready.relative_to(study)),'case_sha256':digest(case),'readiness_sha256':digest(ready)})
schedule=[{'case_id':case['id'],'arm':arm,'repeat':repeat} for repeat,arms in ((1,('native','code-kb')),(2,('code-kb','native'))) for case in cases for arm in arms]
manifest={'schema':1,'status':'ready','cases':cases,'schedule':schedule,'controls':controls,'artifacts':{key:'inputs/'+key for key in paths},'call_limit':28,'budget_gate':'pending','provider_calls':0}
(study/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(lead/'manifest-artifact-paths.json').write_text(json.dumps({k:str(v) for k,v in paths.items()},indent=2)+'\n')
result=e.validate_manifest(study/'manifest.json',artifact_paths=paths)
(lead/'manifest-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
