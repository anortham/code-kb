import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def watch_count(pid):
    count = 0
    for info in (Path('/proc') / str(pid) / 'fdinfo').iterdir():
        try:
            with info.open() as stream:
                count += sum(line.startswith('inotify wd:') for line in stream)
        except OSError:
            pass
    return count


def request(process, identifier, method, params):
    process.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': identifier, 'method': method, 'params': params}) + '\n')
    process.stdin.flush()
    while True:
        line = process.stdout.readline()
        if not line:
            raise RuntimeError('MCP process exited before responding')
        response = json.loads(line)
        if response.get('id') == identifier:
            if 'error' in response or response.get('result', {}).get('isError'):
                raise RuntimeError(str(response))
            return response


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--create-fixture', action='store_true')
    args = parser.parse_args()
    binary, fixture, output = args.binary.resolve(), args.fixture.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    if args.create_fixture:
        fixture.mkdir(parents=True, exist_ok=False)
        (fixture / 'Cargo.toml').write_text('[package]\nname="watch_registration_probe"\nversion="0.1.0"\nedition="2021"\n')
        (fixture / '.gitignore').write_text('ignored/\n')
        for directory in ('src', 'targeted'):
            (fixture / directory).mkdir()
        (fixture / 'src/lib.rs').write_text('pub fn watch_probe() -> u32 { 1 }\n')
        (fixture / 'targeted/allowed.rs').write_text('pub fn allowed_probe() {}\n')
        subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', '-c', 'init.templateDir=', 'init', '--quiet', str(fixture)], check=True, capture_output=True)
        for root in ('target', 'node_modules', '.git/probe', 'ignored'):
            for index in range(250):
                leaf = fixture / root / f'leaf-{index:04}'
                leaf.mkdir(parents=True)
                (leaf / 'ignored.rs').write_text('pub fn excluded_probe() {}\n')
    environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'RUST_LOG': 'info', 'JULIE_EXTRACT_BIN': str(binary.parent / 'julie-extract'), 'CODE_KB_TELEMETRY_DIR': str(output / 'telemetry'), 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1'}
    for key in ('HOME', 'CODEX_HOME'):
        if key in os.environ:
            environment[key] = os.environ[key]
    with (output / 'scan.stdout.log').open('w') as stdout, (output / 'scan.stderr.log').open('w') as stderr:
        subprocess.run([str(binary), 'scan', '--root', str(fixture)], env=environment, stdout=stdout, stderr=stderr, check=True, timeout=60)
    with (output / 'serve.stderr.log').open('w') as stderr:
        process = subprocess.Popen([str(binary), 'serve', '--root', str(fixture)], env=environment, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True)
        try:
            initialized = request(process, 1, 'initialize', {'protocolVersion': '2024-11-05', 'capabilities': {}, 'clientInfo': {'name': 'watch-registration-probe', 'version': '1'}})
            outline = request(process, 2, 'tools/call', {'name': 'file_skeleton', 'arguments': {'project_root': str(fixture), 'file_path': 'src/lib.rs'}})
            if 'watch_probe' not in str(outline):
                raise RuntimeError(f'expected source symbol absent: {outline}')
            samples = []
            for _ in range(5):
                time.sleep(0.1)
                status = dict(line.split(':', 1) for line in (Path('/proc') / str(process.pid) / 'status').read_text().splitlines() if ':' in line)
                samples.append({'watches': watch_count(process.pid), 'rss_kib': int(status['VmRSS'].split()[0]), 'peak_rss_kib': int(status['VmHWM'].split()[0])})
            result = {'schema': 1, 'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'binary': str(binary), 'binary_sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(), 'fixture': str(fixture), 'excluded_leaf_directories': 1000, 'samples': samples, 'initialize': initialized, 'outline': outline, 'provider_calls': 0}
            (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'result': str(output / 'result.json'), 'samples': samples}), flush=True)
        finally:
            process.stdin.close()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=10)


if __name__ == '__main__':
    main()
